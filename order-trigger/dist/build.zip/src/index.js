import AWS from 'aws-sdk';
import rp from 'request-promise'
export function processRequest(event, context, callback) {
    let responseCode = 200;
    const responseBody = {
        message: "Ussd request received"
    };
    let response = {};
    switch (event.httpMethod) {
        case "POST":
            response = {
                statusCode: responseCode,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            publish(event, context, callback);
            context.succeed(response);
            break;
        default:
            responseBody.message = "Please make a POST request with the appropriate JSON payload";
            response = {
                statusCode: 400,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            context.succeed(response);
    };
}
const EMAIL = 'mocheje@c2gconsulting.com';  
const SNS = new AWS.SNS({ apiVersion: '2010-03-31' });
function findExistingSubscription(topicArn, nextToken, cb) {
    const params = {
        TopicArn: topicArn,
        NextToken: nextToken || null,
    };
    SNS.listSubscriptionsByTopic(params, (err, data) => {
        if (err) {
            console.log('Error listing subscriptions.', err);
            return cb(err);
        }
        const subscription = data.Subscriptions.filter((sub) => sub.Protocol === 'email' && sub.Endpoint === EMAIL)[0];
        if (!subscription) {
            if (!data.NextToken) {
                cb(null, null); 
            } else {
                findExistingSubscription(topicArn, data.NextToken, cb); 
            }
        } else {
            cb(null, subscription); 
        }
    });
}
function createSubscription(topicArn, cb) {
    findExistingSubscription(topicArn, null, (err, res) => {
        if (err) {
            console.log('Error finding existing subscription.', err);
            return cb(err);
        }
        if (!res) {
            const params = {
                Protocol: 'email',
                TopicArn: topicArn,
                Endpoint: EMAIL,
            };
            SNS.subscribe(params, (subscribeErr) => {
                if (subscribeErr) {
                    console.log('Error setting up email subscription.', subscribeErr);
                    return cb(subscribeErr);
                }
                console.log(`Subscribed ${EMAIL} to ${topicArn}.`);
                cb(null, topicArn);
            });
        } else {
            cb(null, topicArn);
        }
    });
}
function createTopic(topicName, cb) {
    SNS.createTopic({ Name: topicName }, (err, data) => {
        if (err) {
            console.log('Creating topic failed.', err);
            return cb(err);
        }
        const topicArn = data.TopicArn;
        console.log(`Created topic: ${topicArn}`);
        console.log('Creating subscriptions.');
        createSubscription(topicArn, (subscribeErr) => {
            if (subscribeErr) {
                return cb(subscribeErr);
            }
            console.log('Topic setup complete.');
            cb(null, topicArn);
        });
    });
}
function publish (event, context, callback){
    const number = event.body.sim.msisdn;
    console.log('Received event:', number);
    createTopic('td-ussd-sns-topic', (err, topicArn) => {
        if (err) {
            console.log(err);
            return callback(err);
        }
        console.log(`Publishing to topic ${topicArn}`);
        const params = {
            Message: `${event.body.sim.id} -- processed by Lambda\nPayload: ${JSON.stringify(event.body)}`,
            Subject: `Message received from ${number}: Add customer name`,
            TopicArn: topicArn,
        };
        SNS.publish(params, callback);
    });
};
