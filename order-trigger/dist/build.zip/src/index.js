import AWS from 'aws-sdk';
import rp from 'request-promise'
import bluebird from 'bluebird'
AWS.config.setPromisesDependency(bluebird);
const EMAIL = process.env.email;
const SNS = new AWS.SNS({ apiVersion: '2010-03-31' });
const sqs = new AWS.SQS();
let queueUrl = "";
let receipt  = "";
let customer;
const QueueName = "OrderRequest";
const LeedsQueueName = "LeedsRequest";
const apiUrl = 'https://td-central.herokuapp.com/api/v2/retailer/?';
exports.handler = (event, context, callback) => {
    console.log('Received event:', event);
    if(event.hasOwnProperty('sim')){ 
        let responseCode = 200;
        const responseBody = {
            message: "Request received"
        };
        let response = {};
        switch (event.httpMethod) {
            case "POST":
                response = {
                    statusCode: responseCode,
                    headers: {
                        "x-custom-header": "my custom header value"
                    },
                    body: JSON.stringify(responseBody)
                };
                getCustomerDetails({phone_number: event.body.sim.id}) 
                    .then(data => {
                        customer = JSON.parse(data);
                        return CreateQueue(QueueName)
                    })
                    .then(data => {
                        console.log(data);
                        return sendtoQueue(data.QueueUrl, JSON.stringify(customer))
                    })
                    .then(() => {
                        context.succeed(response);
                    })
                    .catch(err => {
                        console.log(err);
                    });
                break;
            default:
                responseBody.message = "Please make a POST request with the appropriate JSON payload";
                response = {
                    statusCode: 400,
                    headers: {
                        "x-custom-header": "my custom header value"
                    },
                    body: JSON.stringify(responseBody)
                };
                context.succeed(response);
        };
    } else if(event.hasOwnProperty('clickType')) {  
        getCustomerDetails({iot_number: event.serialNumber}) 
            .then(data => {
                const response = JSON.parse(data);
                if(response && response.hasOwnProperty('data') && response.data.hasOwnProperty(message)){
                    customer = event;
                    return CreateQueue(LeedsQueueName);
                } else {
                    customer = response;
                    return CreateQueue(QueueName)
                };
            })
            .then(data => {
                return sendtoQueue(data.QueueUrl, customer ? JSON.stringify(customer): JSON.stringify(event));
            })
            .then(() => {
                createTopic('aws-iot-button-sns-topic', (err, topicArn) => {
                    if (err) {
                        return callback(err);
                    }
                    console.log(`Publishing to topic ${topicArn}`);
                    const params = {
                        Message: customer.hasOwnProperty('clickType') ? 'A new Lead has been found with serial Number ' + event.serialNumber + ' and added to the New Leads queue for further processing'
                            : 'Order Request from ' + customer.outletBusinessName + ', Phone Number: ' + customer.phoneNumber + ', Address: ' + customer.coordinates.formatted_address + '. Request has been added to queue for further processing',
                        Subject: customer.hasOwnProperty('clickType') ? 'New Lead Detected with Serial Number' + event.serialNumber : 'New Order Request from' + customer.outletBusinessName,
                        TopicArn: topicArn,
                    };
                    SNS.publish(params, callback);
                });
            })
            .catch(err => {
                console.log(err);
            });
    } else {
        callback(null);
    }
};
function findExistingSubscription(topicArn, nextToken, cb) {
    const params = {
        TopicArn: topicArn,
        NextToken: nextToken || null,
    };
    SNS.listSubscriptionsByTopic(params, (err, data) => {
        if (err) {
            console.log('Error listing subscriptions.', err);
            return cb(err);
        }
        const subscription = data.Subscriptions.filter((sub) => sub.Protocol === 'email' && sub.Endpoint === EMAIL)[0];
        if (!subscription) {
            if (!data.NextToken) {
                cb(null, null); 
            } else {
                findExistingSubscription(topicArn, data.NextToken, cb); 
            }
        } else {
            cb(null, subscription); 
        }
    });
}
function createSubscription(topicArn, cb) {
    findExistingSubscription(topicArn, null, (err, res) => {
        if (err) {
            console.log('Error finding existing subscription.', err);
            return cb(err);
        }
        if (!res) {
            const params = {
                Protocol: 'email',
                TopicArn: topicArn,
                Endpoint: EMAIL,
            };
            SNS.subscribe(params, (subscribeErr) => {
                if (subscribeErr) {
                    console.log('Error setting up email subscription.', subscribeErr);
                    return cb(subscribeErr);
                }
                console.log(`Subscribed ${EMAIL} to ${topicArn}.`);
                cb(null, topicArn);
            });
        } else {
            cb(null, topicArn);
        }
    });
}
function createTopic(topicName, cb) {
    SNS.createTopic({ Name: topicName }, (err, data) => {
        if (err) {
            console.log('Creating topic failed.', err);
            return cb(err);
        }
        const topicArn = data.TopicArn;
        console.log(`Created topic: ${topicArn}`);
        console.log('Creating subscriptions.');
        createSubscription(topicArn, (subscribeErr) => {
            if (subscribeErr) {
                return cb(subscribeErr);
            }
            console.log('Topic setup complete.');
            cb(null, topicArn);
        });
    });
}
function publish (event, context, callback){
    const number = event.body.sim.msisdn;
    console.log('Received event:', number);
    createTopic('td-ussd-sns-topic', (err, topicArn) => {
        if (err) {
            console.log(err);
            return callback(err);
        }
        console.log(`Publishing to topic ${topicArn}`);
        const params = {
            Message: `${event.body.sim.id} -- processed by Lambda\nPayload: ${JSON.stringify(event.body)}`,
            Subject: `Message received from ${number}: Add customer name`,
            TopicArn: topicArn,
        };
        SNS.publish(params, callback);
    });
};
function CreateQueue(queuename){
    const params = {
        QueueName: queuename
    };
    return sqs.createQueue(params).promise()
};
function listQueue() {
    return sqs.listQueues().promise();
}
 function sendtoQueue(queueUrl, payload) {
    const params = {
        MessageBody: payload,
        QueueUrl: queueUrl,
        DelaySeconds: 0
    };
    return sqs.sendMessage(params).promise()
};
 function receive() {
    var params = {
        QueueUrl: queueUrl,
        VisibilityTimeout: 600 
    };
    return sqs.receiveMessage(params).promise()
};
function deleteMessage() {
    var params = {
        QueueUrl: queueUrl,
        ReceiptHandle: receipt
    };
    return sqs.deleteMessage(params).promise()
};
function purge() {
    var params = {
        QueueUrl: queueUrl
    };
    sqs.purgeQueue(params).promise()
};
function getCustomerDetails(params, type){
    if(type && type === 'local'){
        return new Promise((resolve, reject) => {
            try {
                const customer = require('./fixtures/customer.json');
                resolve(customer);
            } catch(e){
                console.log(e); 
                reject(e);
            }
        })
    } else {
        let endpoint = apiUrl;
        Object.keys(params).map(function(objectKey, index) {
            const queryParams = `&${objectKey}=${params[objectKey]}`;  
            endpoint += queryParams;
        });
        console.log(`generated endpoint is ${endpoint}`);
        return rp(endpoint);
    }
}