'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.processRequest = processRequest;

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_awsSdk2.default.config.setPromisesDependency(_bluebird2.default);
//use global promise

/**
 * This is a sample Lambda function that sends an Email on click of a
 * button. It creates a SNS topic, subscribes an endpoint (EMAIL)
 * to the topic and publishes to the topic.
 *
 * Follow these steps to complete the configuration of your function:
 *
 * 1. Update the EMAIL variable with your email address.
 * 2. Enter a name for your execution role in the "Role name" field.
 *    Your function's execution role needs specific permissions for SNS operations
 *    to send an email. We have pre-selected the "AWS IoT Button permissions"
 *    policy template that will automatically add these permissions.
 */

/**
 * The following JSON template shows what is sent as the payload:
 {
	"sim": {
        "id": 788,
        "iccid": "736826736473829773621",
        "imsi": "901991234567890",
        "msisdn": "+88563748761"
    },

    "imei": "864345678889321",
    "imei_lock": true,
    "ip_address": "10.203.23.75",
 }
 *
 * A "LONG" clickType is sent if the first press lasts longer than 1.5 seconds.
 * "SINGLE" and "DOUBLE" clickType payloads are sent for short clicks.
 *
 * For more documentation, follow the link below.
 * http://docs.aws.amazon.com/iot/latest/developerguide/iot-lambda-rule.html
 */

var EMAIL = 'mocheje@c2gconsulting.com'; // TODO change me
var SNS = new _awsSdk2.default.SNS({ apiVersion: '2010-03-31' });
var sqs = new _awsSdk2.default.SQS();
var queueUrl = "";
var receipt = "";
var customer = "";
var QueueName = "OrderRequest";

function processRequest(event, context, callback) {
    //handle only post request
    var responseCode = 200;
    var responseBody = {
        message: "Request received"
    };
    var response = {};
    switch (event.httpMethod) {
        case "POST":
            response = {
                statusCode: responseCode,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            //publish(event, context, callback);
            //process request
            getCustomerDetails("2433423") //will use event.body.sim.id TODO change me
            .then(function (data) {
                console.log("got here");
                customer = data;
                return CreateQueue(QueueName);
            }).then(function (data) {
                console.log(data);
                return sendtoQueue(data.QueueUrl, JSON.stringify(customer));
            }).then(function () {
                context.succeed(response);
            }).catch(function (err) {
                console.log(err);
            });

            break;

        default:
            responseBody.message = "Please make a POST request with the appropriate JSON payload";
            response = {
                statusCode: 400,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            context.succeed(response);
    };
}

function findExistingSubscription(topicArn, nextToken, cb) {
    var params = {
        TopicArn: topicArn,
        NextToken: nextToken || null
    };
    SNS.listSubscriptionsByTopic(params, function (err, data) {
        if (err) {
            console.log('Error listing subscriptions.', err);
            return cb(err);
        }
        var subscription = data.Subscriptions.filter(function (sub) {
            return sub.Protocol === 'email' && sub.Endpoint === EMAIL;
        })[0];
        if (!subscription) {
            if (!data.NextToken) {
                cb(null, null); // indicate that no subscription was found
            } else {
                findExistingSubscription(topicArn, data.NextToken, cb); // iterate over next token
            }
        } else {
            cb(null, subscription); // a subscription was found
        }
    });
}

/**
 * Subscribe the specified EMAIL to a topic.
 */
function createSubscription(topicArn, cb) {
    // check to see if a subscription already exists
    findExistingSubscription(topicArn, null, function (err, res) {
        if (err) {
            console.log('Error finding existing subscription.', err);
            return cb(err);
        }
        if (!res) {
            // no subscription, create one
            var params = {
                Protocol: 'email',
                TopicArn: topicArn,
                Endpoint: EMAIL
            };
            SNS.subscribe(params, function (subscribeErr) {
                if (subscribeErr) {
                    console.log('Error setting up email subscription.', subscribeErr);
                    return cb(subscribeErr);
                }
                // subscription complete
                console.log('Subscribed ' + EMAIL + ' to ' + topicArn + '.');
                cb(null, topicArn);
            });
        } else {
            // subscription already exists, continue
            cb(null, topicArn);
        }
    });
}

/**
 * Create a topic.
 */
function createTopic(topicName, cb) {
    SNS.createTopic({ Name: topicName }, function (err, data) {
        if (err) {
            console.log('Creating topic failed.', err);
            return cb(err);
        }
        var topicArn = data.TopicArn;
        console.log('Created topic: ' + topicArn);
        console.log('Creating subscriptions.');
        createSubscription(topicArn, function (subscribeErr) {
            if (subscribeErr) {
                return cb(subscribeErr);
            }
            // everything is good
            console.log('Topic setup complete.');
            cb(null, topicArn);
        });
    });
}

function publish(event, context, callback) {
    var number = event.body.sim.msisdn;

    console.log('Received event:', number);
    // create/get topic

    createTopic('td-ussd-sns-topic', function (err, topicArn) {
        if (err) {
            console.log(err);
            return callback(err);
        }
        console.log('Publishing to topic ' + topicArn);
        // publish message
        var params = {
            Message: event.body.sim.id + ' -- processed by Lambda\nPayload: ' + JSON.stringify(event.body),
            Subject: 'Message received from ' + number + ': Add customer name',
            TopicArn: topicArn
        };
        // result will go to function callback
        SNS.publish(params, callback);
    });
};

// Creating a queue.
function CreateQueue(queuename) {

    var params = {
        QueueName: queuename
    };

    return sqs.createQueue(params).promise();
};

// Listing our queues.
function listQueue() {
    return sqs.listQueues().promise();
}

// Sending a message.
// NOTE: Here we need to populate the queue url you want to send to.
// That variable is indicated at the top of app.js.
function sendtoQueue(queueUrl, payload) {
    var params = {
        MessageBody: payload,
        QueueUrl: queueUrl,
        DelaySeconds: 0
    };

    return sqs.sendMessage(params).promise();
};

// Receive a message.
// NOTE: This is a great long polling example. You would want to perform
// this action on some sort of job server so that you can process these
// records. In this example I'm just showing you how to make the call.
// It will then put the message "in flight" and I won't be able to
// reach that message again until that visibility timeout is done.
function receive() {
    var params = {
        QueueUrl: queueUrl,
        VisibilityTimeout: 600 // 10 min wait time for anyone else to process.
    };

    return sqs.receiveMessage(params).promise();
};

// Deleting a message.
function deleteMessage() {
    var params = {
        QueueUrl: queueUrl,
        ReceiptHandle: receipt
    };

    return sqs.deleteMessage(params).promise();
};

// Purging the entire queue.
function purge() {
    var params = {
        QueueUrl: queueUrl
    };

    sqs.purgeQueue(params).promise();
};

function getCustomerDetails(number) {
    //actual get request will be made to retrieve the customers info
    return new Promise(function (resolve, reject) {
        try {
            var _customer = require('./fixtures/customer.json');
            resolve(_customer);
        } catch (e) {
            reject(e);
        }
    });
}